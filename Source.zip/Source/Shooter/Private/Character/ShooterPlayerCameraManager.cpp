// Fill out your copyright notice in the Description page of Project Settings.


#include "Character/ShooterPlayerCameraManager.h"

AShooterPlayerCameraManager::AShooterPlayerCameraManager()
{
	ViewPitchMin = -55.0f;
	ViewPitchMax = 89.0f;
}
