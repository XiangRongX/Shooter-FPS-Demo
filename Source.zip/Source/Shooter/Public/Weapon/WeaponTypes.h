#pragma once

UENUM(BlueprintType)
enum class EWeaponType :uint8
{
	EWT_AssaultRiffle UMETA(DisplayName = "Assault Riffle"),

	EWT_MAX UMETA(DisplayName = "DefaultMAX")
};